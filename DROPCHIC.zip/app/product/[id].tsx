import { useEffect, useState } from "react";
import { FlatList, Pressable, ScrollView, StyleSheet, Text, View, useWindowDimensions, type NativeScrollEvent, type NativeSyntheticEvent } from "react-native";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import { fetchProduct, fetchProductPosts, unitsLeft } from "@/lib/data";
import { SmartVideo } from "@/components/SmartVideo";
import { ProductStats } from "@/components/ProductStats";
import { useCompare, MAX_COMPARE } from "@/lib/compare";
import { useCart } from "@/lib/cart";
import { usePrefs } from "@/lib/prefs";
import { shareProduct } from "@/lib/share";
import { trackAddToCart, trackProductView, trackShare } from "@/lib/track";
import { colors, formatPrice, radius } from "@/lib/theme";
import type { Post, Product } from "@/lib/types";

export default function ProductScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { add } = useCart();
  const { isFavorite, toggleFavorite, markViewed } = usePrefs();
  const compare = useCompare();
  const [compareMsg, setCompareMsg] = useState<string | null>(null);
  const [p, setP] = useState<Product | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [slide, setSlide] = useState(0);
  const [variant, setVariant] = useState<string | null>(null);

  useEffect(() => {
    fetchProduct(id).then((prod) => {
      setP(prod);
      if (prod) { markViewed(prod.id); trackProductView(prod); fetchProductPosts(prod).then(setPosts).catch(() => {}); }
      // Preselect only when there is a single available size; otherwise the buyer must choose.
      const avail = prod ? prod.variants.filter((v) => unitsLeft(prod, v) > 0) : [];
      setVariant(avail.length === 1 ? avail[0] : null);
    });
  }, [id]);

  if (!p) return <View style={{ flex: 1, backgroundColor: colors.white }} />;

  const hasSizes = p.variants.length > 0;
  const soldOut = p.stock <= 0 || (hasSizes && p.variants.every((v) => unitsLeft(p, v) <= 0));
  const needsSize = hasSizes && !variant;
  const canAdd = !soldOut && !needsSize;
  const left = unitsLeft(p, variant);

  // Gallery: the boutique's videos first, then product photos, then extra photo posts.
  type Slide = { key: string; kind: "image" | "video"; url: string; poster?: string | null };
  const slides: Slide[] = [
    ...posts.filter((x) => x.kind === "video").map((x) => ({ key: x.id, kind: "video" as const, url: x.url, poster: x.poster })),
    ...p.images.map((u, i) => ({ key: `img-${i}`, kind: "image" as const, url: u })),
    ...posts.filter((x) => x.kind === "image" && !p.images.includes(x.url)).map((x) => ({ key: x.id, kind: "image" as const, url: x.url })),
  ];

  // web never fires onMomentumScrollEnd → track the page from onScroll too
  const onSwipe = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const i = Math.max(0, Math.min(slides.length - 1, Math.round(e.nativeEvent.contentOffset.x / width)));
    setSlide((cur) => (cur === i ? cur : i));
  };

  const inCompare = compare.has(p.id);
  const onCompare = () => {
    const r = compare.toggle(p.id);
    Haptics.selectionAsync().catch(() => {});
    if (r === "full") setCompareMsg(`Maximum ${MAX_COMPARE} pièces. Retirez-en une pour ajouter celle-ci.`);
    else if (r === "removed") setCompareMsg(null);
    else setCompareMsg(compare.ids.length + 1 >= 2 ? "Ajoutée. Prête à comparer !" : "Ajoutée. Choisissez une autre pièce à comparer.");
  };

  const addToBag = () => {
    if (!canAdd) return;
    add(p, variant);
    trackAddToCart(p);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.back();
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.white }}>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        {slides.length === 0 ? (
          <View style={{ width, height: width * 1.3, backgroundColor: colors.mist, alignItems: "center", justifyContent: "center" }}>
            <Text style={{ color: colors.muted }}>Pas encore de photo</Text>
          </View>
        ) : (
          <View>
            <FlatList
              data={slides}
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              keyExtractor={(sl) => sl.key}
              onScroll={onSwipe}
              scrollEventThrottle={16}
              onMomentumScrollEnd={onSwipe}
              renderItem={({ item, index }) =>
                item.kind === "video" ? (
                  <SmartVideo uri={item.url} poster={item.poster ?? undefined} active={index === slide} muted width={width} height={width * 1.3} />
                ) : (
                  <Image source={{ uri: item.url }} style={{ width, height: width * 1.3 }} contentFit="cover" />
                )
              }
            />
            {slides.length > 1 && (
              <View style={styles.dots} pointerEvents="none">
                {slides.map((sl, i) => <View key={sl.key} style={[styles.dot, i === slide && styles.dotOn]} />)}
              </View>
            )}
          </View>
        )}
        <View style={styles.body}>
          <Pressable onPress={() => router.push({ pathname: "/boutique/[id]", params: { id: p.brand.id } })} hitSlop={6} style={{ alignSelf: "flex-start" }}>
            <Text style={styles.brand}>{p.brand.name}{p.brand.city ? ` · ${p.brand.city}` : ""} ›</Text>
          </Pressable>
          <Text style={styles.name}>{p.name}</Text>
          <Text style={styles.price}>{formatPrice(p.price)}</Text>
          <ProductStats productId={p.id} />

          <View style={styles.compareRow}>
            <Pressable onPress={onCompare} style={[styles.comparePill, inCompare && styles.comparePillOn]} accessibilityRole="button">
              <Text style={[styles.compareText, inCompare && { color: "#fff" }]}>{inCompare ? "✓ Dans la comparaison" : "⇄ Comparer"}</Text>
            </Pressable>
            {compare.ids.length >= 2 ? (
              <Pressable onPress={() => router.push("/compare")} hitSlop={6}>
                <Text style={styles.compareLink}>Voir la comparaison ({compare.ids.length}) ›</Text>
              </Pressable>
            ) : null}
          </View>
          {compareMsg ? <Text style={styles.compareMsg}>{compareMsg}</Text> : null}

          {hasSizes && (
            <View style={{ marginTop: 14 }}>
              <View style={styles.sizeHead}>
                <Text style={styles.sizeLabel}>Taille</Text>
                {variant && left > 0 && left <= 3 ? <Text style={styles.lowStock}>Plus que {left} en stock</Text> : null}
              </View>
              <View style={styles.variants}>
                {p.variants.map((v) => {
                  const out = unitsLeft(p, v) <= 0;
                  const on = variant === v;
                  return (
                    <Pressable
                      key={v}
                      disabled={out}
                      onPress={() => { setVariant(v); Haptics.selectionAsync(); }}
                      style={[styles.variant, on && styles.variantOn, out && styles.variantOut]}
                    >
                      <Text style={[styles.variantText, on && { color: "#fff" }, out && styles.variantTextOut]}>{v}</Text>
                    </Pressable>
                  );
                })}
              </View>
              {p.variants.some((v) => unitsLeft(p, v) <= 0) ? <Text style={styles.sizeHint}>Tailles barrées : épuisées.</Text> : null}
            </View>
          )}
          {!hasSizes && soldOut ? <Text style={styles.soldOut}>Épuisé pour le moment.</Text> : null}

          {p.description ? <Text style={styles.desc}>{p.description}</Text> : null}
        </View>
      </ScrollView>

      <Pressable onPress={() => (router.canGoBack() ? router.back() : router.replace("/(tabs)"))} style={[styles.back, { top: insets.top + 8 }]} hitSlop={8} accessibilityRole="button" accessibilityLabel="Retour">
        <Text style={{ color: colors.ink, fontSize: 18 }}>←</Text>
      </Pressable>
      <View style={[styles.topRight, { top: insets.top + 8 }]}>
        <Pressable onPress={() => { trackShare(p); shareProduct(p); }} style={styles.round} hitSlop={8} accessibilityRole="button" accessibilityLabel="Partager"><Text style={{ color: colors.ink, fontSize: 18 }}>↗</Text></Pressable>
        <Pressable onPress={() => { toggleFavorite(p); Haptics.selectionAsync().catch(() => {}); }} style={styles.round} hitSlop={8}>
          <Text style={{ color: isFavorite(p.id) ? colors.pink : colors.ink, fontSize: 18 }}>{isFavorite(p.id) ? "♥" : "♡"}</Text>
        </Pressable>
      </View>

      <View style={[styles.footer, { paddingBottom: insets.bottom + 14 }]}>
        <Pressable onPress={addToBag} disabled={!canAdd} style={[styles.cta, !canAdd && styles.ctaOff]}>
          <Text style={[styles.ctaText, !canAdd && { color: colors.muted }]}>
            {soldOut ? "Épuisé" : needsSize ? "Choisissez une taille" : `Ajouter au panier · ${formatPrice(p.price)}`}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  dots: { position: "absolute", bottom: 12, left: 0, right: 0, flexDirection: "row", justifyContent: "center", gap: 6 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "rgba(255,255,255,0.55)" },
  dotOn: { backgroundColor: "#fff", width: 18 },
  body: { padding: 18, gap: 6 },
  brand: { color: colors.muted, fontSize: 14 },
  name: { color: colors.ink, fontSize: 26, fontWeight: "700", letterSpacing: -0.5 },
  price: { color: colors.ink, fontSize: 17 },
  sizeHead: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sizeLabel: { fontSize: 13, color: colors.muted, fontWeight: "600" },
  lowStock: { fontSize: 12, color: colors.pink, fontWeight: "600" },
  sizeHint: { fontSize: 12, color: colors.muted, marginTop: 8 },
  soldOut: { fontSize: 14, color: colors.pink, fontWeight: "600", marginTop: 12 },
  variants: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 },
  variant: { minWidth: 48, alignItems: "center", paddingHorizontal: 14, paddingVertical: 9, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.line },
  variantOn: { backgroundColor: colors.ink, borderColor: colors.ink },
  variantOut: { backgroundColor: colors.mist, borderColor: colors.mist },
  variantText: { color: colors.ink, fontSize: 14, fontWeight: "600" },
  variantTextOut: { color: colors.muted, textDecorationLine: "line-through" },
  compareRow: { flexDirection: "row", alignItems: "center", gap: 12, marginTop: 12, flexWrap: "wrap" },
  comparePill: { borderWidth: 1, borderColor: colors.ink, borderRadius: radius.pill, paddingHorizontal: 14, paddingVertical: 8 },
  comparePillOn: { backgroundColor: colors.ink },
  compareText: { color: colors.ink, fontWeight: "700", fontSize: 13 },
  compareLink: { color: colors.violet, fontWeight: "700", fontSize: 13 },
  compareMsg: { color: colors.muted, fontSize: 12, marginTop: 6 },
  desc: { color: colors.muted, fontSize: 15, lineHeight: 22, marginTop: 14 },
  back: { position: "absolute", left: 14, width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.9)", alignItems: "center", justifyContent: "center" },
  topRight: { position: "absolute", right: 14, flexDirection: "row", gap: 8 },
  round: { width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.9)", alignItems: "center", justifyContent: "center" },
  footer: { position: "absolute", left: 0, right: 0, bottom: 0, padding: 16, backgroundColor: colors.white, borderTopWidth: 1, borderTopColor: colors.line },
  cta: { backgroundColor: colors.ink, height: 52, borderRadius: radius.pill, alignItems: "center", justifyContent: "center" },
  ctaOff: { backgroundColor: colors.mist },
  ctaText: { color: "#fff", fontWeight: "700", fontSize: 16 },
});
